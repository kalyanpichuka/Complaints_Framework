#!/home/ignitelab/anaconda3/bin/python
from flask import Flask
from flask import request
from flask import jsonify
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
from collections import OrderedDict
from pgmpy.models import BayesianModel
from pgmpy.factors.discrete import TabularCPD
from pgmpy.estimators import ParameterEstimator
from pgmpy.estimators import BayesianEstimator
from pgmpy.inference import VariableElimination

print("************************************************************************************************************")
print("**********************************LOADING THE MODEL*********************************************************")
print("************************************************************************************************************")

data = pd.read_csv("ComplaintsDataSet_9_3_2018.csv")


model = BayesianModel([('State', 'City'),('City', 'Issue'), ('Submitted via', 'Issue'), ('Company response to consumer','Issue')])

model.fit(data, estimator=BayesianEstimator, prior_type="BDeu")

issue_inference = VariableElimination(model)

print("************************************************************************************************************")
print("**********************************COMPLETED LOADING THE MODEL***********************************************")
print("************************************************************************************************************")

state_dict = {}
city_dict = {}
submitted_via_dict = {}
company_response_dict = {}
issue_dict = {}

state_list = sorted(list(data['State'].unique()))
city_list = sorted(list(data['City'].unique()))
submitted_via_list = sorted(list(data['Submitted via'].unique()))
company_response_list = sorted(list(data['Company response to consumer'].unique()))
issue_list = sorted(list(data['Issue'].unique()))

city_count = len(city_list)
submitted_via_count = len(submitted_via_list)
company_response_count = len(company_response_list)
issue_count = len(issue_list)
state_count = len(state_list)


i=0
for state in state_list:
  state_dict[state] = i
  i += 1

i=0
for city in city_list:
  city_dict[city] = i
  i += 1

i=0
for submitted_via in submitted_via_list:
  submitted_via_dict[submitted_via] = i
  i += 1


i=0
for company_response in company_response_list:
  company_response_dict[company_response] = i
  i += 1

i=0
for issue in issue_list:
  issue_dict[issue] = i
  i += 1


# CUSTOMER RELATED MODEL

model2 = BayesianModel([('Customer_id','Issue'),('Submitted via', 'Issue'),('Company response to consumer','Issue')])
model2.fit(data, estimator=BayesianEstimator, prior_type="BDeu")
issue_inference2 = VariableElimination(model2)

customer_dict = {}
customer_list = sorted(list(data['Customer_id'].unique()))
customer_count = len(customer_list)
i=0
for customer in customer_list:
  customer_dict[customer] = i
  i += 1


#RETRIVING KEYS RELATED TO TOP MAX VALUES
def _get_max_value_keys(array,res_dict):
  result=[]
  for element in array:
    result.append([key for key, value in res_dict.items() if value == element][0])
  return result

# RETRIVING ISSUES BASED ON THE CITY,SUBMITTED VIA,COMPANY RESPONSE
def _get_issues_(city,submitted_via,company_response):
  result=[]
  prob_issue_multiple = issue_inference.query( variables = ['Issue'],evidence = {'City':city_dict[city],'Submitted via':submitted_via_dict[submitted_via],'Company response to consumer':company_response_dict[company_response]})
  result = _get_max_value_keys(prob_issue_multiple['Issue'].__dict__['values'].argsort()[-1:-4:-1],issue_dict)
  return result 


# RETRIVING ISSUES BASED ON THE CITY,SUBMITTED VIA,COMPANY RESPONSE ALONG WITH PROBABILITIES

def _get_issues_latest_(state,city,submitted_via,company_response):
  result=[[],[]]
  prob_issue_multiple = issue_inference.query(variables = ['Issue'],evidence = {'State':state_dict[state],'City':city_dict[city],'Submitted via':submitted_via_dict[submitted_via],'Company response to consumer':company_response_dict[company_response]})
  prob_values = prob_issue_multiple['Issue'].__dict__['values']
  #print(prob_values)
  #prob_sum = np.sum(prob_values)
  #print(prob_sum)
  max_value_indices = prob_values.argsort()[-1:-4:-1]
  #print(max_value_indices)
  result[0] = _get_max_value_keys(max_value_indices,issue_dict)
  result[1] = [prob_values[index] for index in max_value_indices]
  return result

# RETRIVING ISSUES BASED ON THE CITY,SUBMITTED VIA,COMPANY RESPONSE,CUSTOMER_ID
def _get_issues_latest_customers_(submitted_via,company_response,customer_id):
  result=[[],[]]
  prob_issue_multiple = issue_inference2.query(variables = ['Issue'],evidence = {'Submitted via':submitted_via_dict[submitted_via],'Company response to consumer':company_response_dict[company_response],'Customer_id':customer_dict[customer_id]})
  prob_values = prob_issue_multiple['Issue'].__dict__['values']
  #print(prob_values)
  #prob_sum = np.sum(prob_values)
  #print(prob_sum)
  max_value_indices = prob_values.argsort()[-1:-4:-1]
  #print(max_value_indices)
  result[0] = _get_max_value_keys(max_value_indices,issue_dict)
  result[1] = [prob_values[index] for index in max_value_indices]
  return result  

print("************************************************************************************************************")
print("**********************************SERVER STARTED WITH REQUIRED UTILITIES************************************")
print("************************************************************************************************************")


app = Flask(__name__)

empDB=[
 {
 'id':'101',
 'name':'Saravanan S',
 'title':'Technical Leader'
 },
 {
 'id':'201',
 'name':'Rajkumar P',
 'title':'Sr Software Engineer'
 }
 ]

@app.route('/')
def index():
    return "Hello, World!"

@app.route('/display', methods=['GET'])
def getName():
    firstname = request.args.get('firstname')
    lastname = request.args.get('lastname')
    result = [{'first':firstname,'last':lastname}]
    return jsonify({'name':result})

@app.route('/maxProb', methods=['GET'])
def getMaxProb():
    city = request.args.get('city')
    sub_via = request.args.get('sub_via')
    comp_res = request.args.get('comp_res')
    prob = _get_issues_(city,sub_via,comp_res) 	
    result = [{'firstmax':prob[0],'secondmax':prob[1],'thirdmax':prob[2]}]
    return jsonify({'name':result})

@app.route('/maxProbLatest', methods=['GET'])
def getMaxProbLatest():
    state = request.args.get('state')
    city = request.args.get('city')
    sub_via = request.args.get('sub_via')
    comp_res = request.args.get('comp_res')
    prob = _get_issues_latest_(state,city,sub_via,comp_res) 	
    result_1 = [{'firstmax':prob[0][0],'secondmax':prob[0][1],'thirdmax':prob[0][2]}]
    result_2 = [{'firstmax':prob[1][0],'secondmax':prob[1][1],'thirdmax':prob[1][2]}]
    return jsonify({'keys':result_1,'values':result_2})

@app.route('/maxProbCustomerLatest', methods=['GET'])
def getMaxProbCustomerLatest():
    sub_via = request.args.get('sub_via')
    comp_res = request.args.get('comp_res')
    cust_id = request.args.get('cust_id')
    prob = _get_issues_latest_customers_(sub_via,comp_res,cust_id) 	
    result_1 = [{'firstmax':prob[0][0],'secondmax':prob[0][1],'thirdmax':prob[0][2]}]
    result_2 = [{'firstmax':prob[1][0],'secondmax':prob[1][1],'thirdmax':prob[1][2]}]
    return jsonify({'keys':result_1,'values':result_2})



@app.route('/empdb/employee',methods=['GET'])
def getAllEmp():
    return jsonify({'emps':empDB})

if __name__ == '__main__':
    app.run(debug=True)
